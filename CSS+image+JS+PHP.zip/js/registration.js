
/*This is a regex for password: at least one number、one uppercase、 one lowercase letter
and one of (!#@%^)and between 6 and 12 characters*/
var regexPassword=/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!#$%^])[^]{6,12}$/;

/*This is the format requirement of the mailbox*/
var regexEmail=/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{1,5})+$/;

/*The function is for student registration validation*/
function stuvalidation() {

   /* Check if student name is empty*/
    if($("#name").val()==""){
        alert("Please enter your name.");
        return false;
    }
    /*Check if student ID is empty*/
    else if($("#studentname").val()==""){
        alert("Please enter your student Name.");
        return false;
    }
    /*Check if student password is empty*/
    else if($("#password").val()==""){
        alert("Please enter your password.");
        return false;
    }
    /*Check whether the student password meets the requirements */
    else if(!regexPassword. test($("#password").val())){
        alert("Password must contain at least one number、one uppercase、 one lowercase letter and one of following special characters(!#@%^), and between 6 and 12 characters.");
        return false;
    }
    /*Check if Confirm password is empty*/
    else if($("#Confirm_password").val()==""){
        alert("Please re-type the password.");
        return false;
    }
   /* Check whether the student password matches the confirm password*/
    else if($("#password").val()!=$("#Confirm_password").val()){
        alert("Please confirm that the passwords match");
        return false;
    }
    /*Check if the email is empty*/
    else if ($("#email").val()==""){
        alert("Please enter your valid email address.");
        return false;
    }
    /*Check whether the email meets the requirements*/
    else if (!regexEmail.test($("#email").val())){
        alert("Please enter the correct email format.");
        return false;
    }
    return true;
}

/*The function is for staff registration validation*/
function stavalidation() {

    /* Check if staff name is empty*/
    if($("#name").val()==""){
        alert("Please enter your name.");
        return false;
    }
    /* Check if student ID is empty*/
    else if($("#staffName").val()==""){
        alert("Please enter your staff ID.");
        return false;
    }
    /* Check if staff  password is empty*/
    else if($("#staffpassword").val()==""){
        alert("Please enter your password.");
        return false;
    }
    /*Check whether the staff password meets the requirements */
    else if(!regexPassword. test($("#staffpassword").val())){
        alert("Password must contain at least one number、one uppercase、 one lowercase letter and one of following special characters(!#@%^), and between 6 and 12 characters.");
        return false;
    }
    /* Check if staff confirm password is empty*/
    else if($("#staffConfirm_password").val()==""){
        alert("Please re-type the password.");
        return false;
    }
    /* Check whether the staff password matches the confirm password*/
    else if($("#staffpassword").val()!=$("#staffConfirm_password").val()){
        alert("Please confirm that the passwords match");
        return false;
    }
    /* Check if staff email is empty*/
    else if ($("#staffemail").val()==""){
        alert("Please enter your valid email address.");
        return false;
    }
    /*Check whether the staff email the requirements */
    else if (!regexEmail.test($("#staffemail").val())){
        alert("Please enter the correct email format.");
        return false;
    }
    /* Check if qualification is empty*/
    else if($("#qualification").val()==""){
        alert("Please select options");
        return false;
    }
    /* Check if expertise is empty*/
    else if($("#expertise").val()==""){
        alert("Please select options");
        return false;
    }
    /* Check if staff phone number is empty*/
    else if($("#staffphonenumber").val()==""){
        alert("Please enter your Phone number");
        return false;
    }
    return true;

}