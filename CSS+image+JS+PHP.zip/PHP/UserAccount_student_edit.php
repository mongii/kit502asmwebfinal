<?php
include('../db_conn.php'); //db connection

header('Content-Type: application/json');



$mysqli = new mysqli('localhost', 'thyvo', '513579', 'thyvo');

if (mysqli_connect_errno()) {
    echo json_encode(array('mysqli' => 'Failed to connect to MySQL: ' . mysqli_connect_error()));
    exit;
}



$input = filter_input_array(INPUT_POST);
$ID = mysqli_real_escape_string($mysqli,$input['ID']);
$username = mysqli_real_escape_string($mysqli,$input['username']);
$studentname = mysqli_real_escape_string($mysqli,$input['studentname']);
$email = mysqli_real_escape_string($mysqli,$input['email']);
$address = mysqli_real_escape_string($mysqli,$input['address']);
$dateofbirth = mysqli_real_escape_string($mysqli,$input['dateofbirth']);
$phonenumber = mysqli_real_escape_string($mysqli,$input['phonenumber']);



if ($input['action']=='edit'){
    $query ="UPDATE `Student` SET `username`='$username',`studentname`='$studentname',`email`='$email',`address`='$address',`dateofbirth`='$dateofbirth',`phonenumber`='$phonenumber' WHERE `ID`='$ID'";
    $result = $mysqli->query($query);
}else if($input['action']=='delete'){
    $query = "DELETE FROM `Student` WHERE `ID`='$ID'";
    $result=$mysqli->query($query);
}
mysqli_close($mysqli);

echo json_encode($input);
