<?php

session_start();
if(!isset($_SESSION['session_user']))
{
    $_SESSION['session_user']="";
}
if (!isset($_SESSION['session_access']))
{
    $_SESSION['session_access']="";
}
$session_user=$_SESSION['session_user'];
$session_access=$_SESSION['session_access'];