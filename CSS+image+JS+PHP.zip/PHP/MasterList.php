<?php
include('../db_conn.php'); //db connection
include "Login_Validation.php";
include "session.php";

if($session_access!='DC'){
    echo '
        <script>
            alert("You do not have access to this page!");
            window.history.back();
        </script>
    ';

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Master List</title>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <link rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
              integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <script src="../js/jquery.tabledit.min.js"></script>
        <script>
            $(document).ready(function (){
                /*when user clicks the search button, execute the following function*/
                $('button[type!=submit]').click(function () {
                    return false;
                });
                $("#search").click(function() {
                    var searchContent = $("#searchContent").val();
                    if ($("#searchContent").val() == "") {
                        alert("Please enter key words!");
                    } else {
                        $.get("Masterunit_search.php", {searchContent: searchContent}).done(function (data) {
                            if (data=='nochange')
                            {alert("Don\'t have a record");
                            }
                            else {
                                $("#output").html(data);}
                        });
                    }
                });
                $("#close").click(function (){
                    location.reload();
                });
                $(".close").click(function (){
                    location.reload();
                });
            });
        </script>
    </head>
    <body>
    <!-- Edit unit table-->
    <script>
        $(document).ready(function (){
            $('#tabledit').Tabledit({
                url:'Masterunit_add.php',
                columns:{
                    identifier:[0,'UnitID'],
                    editable:[[1,'UnitName'],[2,'UnitDescription'],[3,'OfferingSemester'],[4,'Campuses']]
                },
                restoreButton:false,
            })
        })
    </script>
        <div class="container" id="bdiv">


           <div class="row flex-nowrap justify-content-between align-items-center">
    <!--registration -->
            <!-- if user is not logged in, the registration button will be displayed  -->
            <?php
                include "PHP/session.php";
                    if ($session_user==""){
                        echo ' <div class="col-4 pt-1">
                                <a href="PHP/Registration.php" class="btn btn-success">Registration</a>
                               </div>';
                    }
                    ?>
            
            <div class="col-4 text-center">
                <h3 class="blog-header-logo text-dark" id="UDW">University of DoWell</h3>
            </div>
    <!--login & logout -->
            <!--the login button will be displayed if there is no login, and the logout button will be displayed if there is a login-->
            <div class="col-4 d-flex justify-content-end align-items-center">
                <?php
                if ($session_user==""){
                    echo'<a href="PHP/Login.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Login</a>';
                } else{
                    echo'<a href="PHP/LogOut.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Logout</a>';
                }
                ?>
            </div>
        </div>
    </header>

     <!-- navigation bar-->
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: black;">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

    
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <nav class="nav d-flex justify-content-between">
                <li class="navbar-brand">
                    <a class="nav-link" href="../Home.php">Home</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitDetail.php">Unit Detail</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitEnrollment.php">Unit Enrollment</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="IndividualTimetable.php">Individual Timetable</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="TutorialAllocation.php">Tutorial Allocation</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterList.php">Master List</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterStaff.php">Master Staff</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="EnrolledStudentDetails.php">Enrolled Student</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitManagement.php">Unit Management</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UserAccount.php">User Account</a>
                </li>
                </ul>
            </nav>
        </div>
    </div>
    <!-- Whenever user sign in, their user name will be shown after "Welcome ". -->
    <div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card">
                <img class="card-img-top" src="../image/picture1.jpg" alt="loading" style="width: 100%" height="450"><br>
                <h4>Welcome to University of DoWell</h4>
                <p>Course Management System</p>
                <p> Welcome 
                <?php  echo $session_user;
                        echo $session_access;

              ?> </p>
            </div>
        </div>
</div>

                <!-- intro--> 
                <div>
                    <h1 class="display-5 font-italic">Master Unit</h1>
                </div>
            </div>
        </div>
                <div class ="container">
                        <h2 align ="center">Manage Unit details</h2>
                        <!--query for retrieving all the items from the unit table-->
                        <?php
                        $query="SELECT * FROM `unit`";
                        $result=$mysqli->query($query);
                        ?>
                        <!--Button trigger modal-->
                    <button type="submit" class="btn btn-secondary btn-sm float-right" data-toggle="modal" data-target="#ModalLong">Search</button>
                    <!-- Creat a table-->
                    <table id="tabledit" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit ID</th>
                                <th>Unit Name</th>
                                <th>Unit Description</th>
                                <th>Semester</th>
                                <th>Campuses</th>
                            </tr>
                            </thead>
                            <tbody>
                            <!--  covert the above result into array (associative array)-->
                            <!-- keys of the array are the column name-->
                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitID']?></td>
                                    <td><?php echo $rows['UnitName']?></td>
                                    <td><?php echo $rows['UnitDescription']?></td>
                                    <td><?php echo $rows['OfferingSemester']?></td>
                                    <td><?php echo $rows['Campuses']?></td>
                                </tr>
                            <?php  }
                            ?>
                            </tbody>
                        </table>
                        <!-- Modal-->
                        <div class="modal" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <!--Modal head-->
                                    <div class="modal-header">
                                        <h5 class="modal-title" id=ModalLongTitle">Search</h5>
                                        <button type="submit" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <!-- Modal body-->
                                    <div class="modal-body" id="output" for"searchContent">
                                    <p>Search</p>
                                    <form method="post" >
                                        <input type="text" class="form-control" id="searchContent" name="searchContent">
                                        <br>
                                        <button class="btn  btn-sm btn-warning" id="search">Search</button>
                                    </form>
                                </div>
                                <!-- Modal footer-->
                                <div class="modal-footer">
                                    <button type="submit" id="close" class="btn btn-light" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Button trigger modal -->
                    <button type="submit" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
                        Add New Unit
                    </button>

                    <!-- Modal -->
                    <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title" id="exampleModalLabel">Add New Unit</h2>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <!-- Modal body-->
                                <div class="modal-body">
                                    <form method="post" onsubmit="return validation()">
                                        <p>
                                            <lable>Unit Name</lable>
                                            <input class="form-control" type="text" id="unit_name"  name="unit_name">
                                        </p>
                                        <p>
                                            <lable>Unit Description</lable>
                                            <input class="form-control" type="text" id="unitdescription"  name="unitdescription">
                                        </p>
                                        <p>
                                            <lable>Semester</lable>
                                            <input class="form-control" type="text" id="semester"  name="semester">
                                        </p>
                                        <p>
                                            <lable>Campuses</lable>
                                            <input class="form-control" type="text" id="campuses"  name="campuses">
                                        </p>
                                        <input name="submit" type="submit"  value="Add" class="btn btn-success btn-sm">
                                        <!--Add information to the database-->
                                        <?php
                                        if ($_SERVER["REQUEST_METHOD"] == 'POST') {
                                            $unitName = $_POST['unit_name'];
                                            $unitDescription = $_POST['unitdescription'];
                                            $semester = $_POST['semester'];
                                            $campuses = $_POST['campuses'];
                                            $query = "INSERT INTO `unit`(`UnitName`, `UnitDescription`, `OfferingSemester`, `Campuses`) VALUES ('$unitName','$unitDescription','$semester','$campuses')";
                                            $result = $mysqli->query($query);
                                            if ($result){
                                                echo '<meta http-equiv="refresh" content="0">';
                                            }else{
                                                echo ('ADD failed');
                                            }
                                            $mysqli->close();
                                        }
                                        ?>
                                    </form>
                                </div>
                                <!-- Modal footer-->
                                <div class="modal-footer">
                                    <button type="submit"  class="btn btn-light btn-sm" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                <div>

        <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
        </div>

        
    <script>
        /*The function is for add information validation*/
        function validation() {
            /* Check if Unit Name is empty*/
            if($("#unit_name").val()==""){
                alert("Unit Name is required");
                return false;
            }
            /* Check if Unit Description is empty*/
            else if($("#unitdescription").val()==""){
                alert("Unit Description is required");
                return false;
            }
            /* Check if Semester is empty*/
            else if($("#semester").val()==""){
                alert("Semester is required");
                return false;
            }
            /* Check if Campuses is empty*/
            else if($("#campuses").val()==""){
                alert("Campuses is required");
                return false;
            }
            return true;

        }
    </script>
    </body>
<!-- footer -->
<footer align="center" style="font-weight: bold; background-color: white">
            <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
            <p>Copyright © 2020 Yen Vo. All right reserved. </p>
    </footer>

</html>