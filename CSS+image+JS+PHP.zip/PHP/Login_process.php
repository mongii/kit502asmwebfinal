<?php
include('../db_conn.php');
include ('session.php');

$username=$_POST['username'];
$password=$_POST['password'];

$encrypted_password=crypt($password,'salt');


$query_student = "SELECT * FROM `Student` WHERE `username`= '$username'";
$result_student=$mysqli->query($query_student);
$row_student=$result_student->fetch_array(MYSQLI_ASSOC);
$student_count=$result_student->num_rows;

$query_staff = "SELECT * FROM `Staff` WHERE `username`= '$username'";
$result_staff=$mysqli->query($query_staff);
$row_staff =$result_staff->fetch_array(MYSQLI_ASSOC);
$staff_count=$result_staff->num_rows;

//Determine whether the logged-in user is a student or an employee
if($student_count==0){
    if($staff_count==0){
        echo '<script>alert("Invalid username!");
        window.history.back();
        </script>';
    }else{
        if($row_staff['password']==$encrypted_password)

        {
            $_SESSION['session_user']=$row_staff['username'];
            $_SESSION['session_access']=$row_staff['accesslevel'];
            header('Location:../Home.php');
        }else{
            echo '<script>alert("Password does not match!");
            window.history.back();
            </script>';
        }
    }
}else{
    if($row_student['password']==$encrypted_password)

    {
        $_SESSION['session_user']=$row_student['username'];
        $_SESSION['session_access']=$row_student['accesslevel'];
        header('Location:../Home.php');
    }else{
        echo '<script>alert("Password does not match!");
            window.history.back();
            </script>';
    }
}