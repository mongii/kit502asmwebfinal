<?php
include('../db_conn.php'); //db connection
include "Login_Validation.php";
include "session.php";

if($session_access!='student'){
    echo '
        <script>
            alert("You do not have access to this page!");
            window.history.back();
        </script>
    ';
}

//get the q parameter from URL
$unitCode=$_GET["unitCode"];
$tuteCode=$_GET["tuteCode"];

$list_query = "SELECT * FROM classDetail WHERE tuteCode='$tuteCode' And UnitCode='$unitCode'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);
$result_cnt = $result->num_rows;

if($result_cnt!=0)
{
    $row= $result->fetch_array(MYSQLI_ASSOC);
    $UnitName = $row['UnitName'];
    $time=$row['time'];
    $type=$row['type'];
    $Room=$row['Room'];

  $list_query = "INSERT INTO `allocate` (`tuteCode`, `UnitCode`, `UnitName`,`time`, `username`,`type`,`Room`)
                    VALUES ('$tuteCode','$unitCode','$UnitName','$time','$session_user','$type','$Room')";

    $result= $mysqli->query($list_query);

    $query = "UPDATE `classDetail` SET num=num+1 WHERE tuteCode='$tuteCode'";

    $mysqli->query($query);
}
?>

