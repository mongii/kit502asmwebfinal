<?php
include "session.php";
if($session_user==""){
    echo '
        <script>
            alert("Please log in to access the page!");
            window.location.href = "Login.php";
        </script>
    ';

}