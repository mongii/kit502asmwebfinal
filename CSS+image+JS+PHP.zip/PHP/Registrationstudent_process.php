<?php
include('../db_conn.php');
include ('session.php');
$username=$_POST['username'];
$studentname=$_POST['studentname'];
$password=$_POST['password'];
$email=$_POST['email'];
$address=$_POST['address'];
$dateofbirth=$_POST['dateofbirth'];
$phonenumber=$_POST['phonenumber'];

$encrypted_password=crypt($password,'salt');


$query = "SELECT * FROM `Student` WHERE `username`= '$username'";
$result=$mysqli->query($query);
$result_cunt=$result->num_rows;
if ($result_cunt=="0"){

    $query="INSERT INTO `Student`(`username`, `studentname`, `password`, `email`, `address`, `dateofbirth`, `phonenumber`, `accesslevel`) 
                     VALUES ('$username','$studentname','$encrypted_password','$email','$address','$dateofbirth','$phonenumber','student')";
    $result=$mysqli->query($query);
    echo '<script>alert("Sign up successfully!")</script>';
    $_SESSION['session_user']=$username;
    $_SESSION['session_access']='student';
    header('Home.php');
}else{
    echo '<script>
         alert("Username Exists!");
         window.history.back();
         </script>';
}
