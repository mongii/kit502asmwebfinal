<?php

include('../db_conn.php');
include "session.php";
if($session_access!='student'){
    echo '
        <script>
            alert("You are not allowed to access this page!");
            window.history.back();
        </script>
    ';
}


//get the q parameter from URL
$unitCode=$_GET["code"];

$list_query = "SELECT * FROM unit_enrolled WHERE UnitCode='$unitCode' AND username='$session_user'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);
$result_cnt = $result->num_rows;

//covert the above result into array (associative array)
if($result_cnt!=0)
{
    echo '<script>alert("You have enrolled in this unit!")</script>';
}
else
{
    //query for retreiving all the items from the unit table
    $list_query = "SELECT * FROM unit WHERE UnitCode= '$unitCode'";
    //execute the query 'list_query'
    $result= $mysqli->query($list_query);
    $result_cnt = $result->num_rows;

    //covert the above result into array (associative array)
    if($result_cnt!=0)
    {
        $row= $result->fetch_array(MYSQLI_ASSOC);
    }

    //extract the values
    $unitName=$row['UnitName'];
    $OfferingSemester=$row['OfferingSemester'];
    $Campuses=$row['Campuses'];
    $type=$row['type'];
    $time=$row['time'];


    $query = " INSERT INTO `unit_enrolled`(`UnitCode`, `UnitName`, `OfferingSemester`, `Campuses`, `username`, `type`,`time`)
    VALUES ('$unitCode','$unitName','$OfferingSemester','$Campuses','$session_user','$type','$time')";
    $mysqli->query($query);
    echo '<script>alert("Successfully enrolled!")</script>';
}
?>
