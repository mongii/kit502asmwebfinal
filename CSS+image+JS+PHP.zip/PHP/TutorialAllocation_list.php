<?php
include('../db_conn.php');
include "session.php";
if($session_access!='student'){
    echo '
        <script>
            alert("You do not have access to this page!");
            window.history.back();
        </script>
    ';
}


//get the q parameter from URL
$unitCode=$_GET["unitCode"];

$list_query = "SELECT * FROM unit_enrolled WHERE UnitCode='$unitCode' AND username='$session_user'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);
$result_cnt = $result->num_rows;
if($result_cnt!=0)
{
    //get the q parameter from URL
    $list_query = "SELECT * FROM `allocate` WHERE UnitCode='$unitCode' AND username='$session_user'";
    //execute the query 'list_query'
    $result= $mysqli->query($list_query);
    $result_cnt = $result->num_rows;
    if($result_cnt==0)
    {
        $list_query = "SELECT * FROM classDetail WHERE UnitCode='$unitCode'";
        //execute the query 'list_query'
        $result= $mysqli->query($list_query);
        $result_cnt = $result->num_rows;

        if($result_cnt!=0)
        {
            $str = '<table class="table table-striped table-sm">
				  <thead>
					<tr>
					  <th>Unit Code</th>
					  <th>Tutorial Code</th>
					  <th>Time</th>
					  <th>num/max</th>
					  <th>Allocate</th>
					</tr>
				  </thead>
				  <tbody>';
            $i=1;
            while($row= $result->fetch_array(MYSQLI_ASSOC)){
                //extract the values
                $tuteCode=$row['tuteCode'];
                $time=$row['time'];
                $num=$row['num'];
                $max=$row['max'];
                if($i==1)
                {
                    //printing out with table :)
                    $str = $str."
									<tr>
									  <td>$unitCode</td>
									  <td>$tuteCode</td>
									  <td>$time</td>
									  <td>$num/$max</td>
									  <td><input type='radio' id='suburbs' name='$unitCode' value='$tuteCode' checked></td>
									</tr>";
                }
                else
                {
                    $str = $str."
									<tr>
									  <td>$unitCode</td>
									  <td>$tuteCode</td>
									  <td>$time</td>
									  <td>$num/$max</td>
									  <td><input type='radio' id='suburbs' name='$unitCode' value='$tuteCode'></td>
									</tr>";
                }
                $i=$i+1;
            }
            $str = $str."</tbody>
				</table><button type='button' class='btn btn-primary' onclick='follow()'>Allocate</button>";
            echo $str;
        }
    }
    else{
        echo '<script>alert("You have allocated a tutorial for this unit!")</script>';
    }
}
else{
    echo '<script>alert("You have not enrolled this unit")</script>';
}
?>
