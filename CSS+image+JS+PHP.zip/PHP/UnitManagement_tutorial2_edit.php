<?php
include('../db_conn.php'); //db connection

header('Content-Type: application/json');



$mysqli = new mysqli('localhost', 'thyvo', '513579', 'thyvo');

if (mysqli_connect_errno()) {
    echo json_encode(array('mysqli' => 'Failed to connect to MySQL: ' . mysqli_connect_error()));
    exit;
}



$input = filter_input_array(INPUT_POST);
$tuteCode = mysqli_real_escape_string($mysqli,$input['tuteCode']);
$time = mysqli_real_escape_string($mysqli,$input['time']);
$consultation = mysqli_real_escape_string($mysqli,$input['consultation']);
$Room = mysqli_real_escape_string($mysqli,$input['Room']);

if ($input['action']=='edit'){
    $query ="UPDATE `classDetail` SET `time`='$time',`consultation`='$consultation',`Room`='$Room' WHERE `tuteCode`='$tuteCode'";
    $result = $mysqli->query($query);
}else if($input['action']=='delete'){
    $query = "DELETE FROM `classDetail` WHERE `tuteCode`='tuteCode'";
    $result=$mysqli->query($query);
}
mysqli_close($mysqli);

echo json_encode($input);

