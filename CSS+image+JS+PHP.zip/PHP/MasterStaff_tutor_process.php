<?php
include "../db_conn.php";
include "session.php";

$tuteCode=$_GET['col1'];
$tutor=$_GET['col2'];

$query ="UPDATE `classDetail` SET `tutor`='$tutor' WHERE `tuteCode`='$tuteCode'";
$result = $mysqli->query($query);

if($result){
    echo "The".$tuteCode."'s lecturer has successfully changed to ".$tutor;
}