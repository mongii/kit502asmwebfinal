<?php

include('../db_conn.php');
/*get the q parameter from URL*/
$search= $_GET["searchContent"];

$query="SELECT * FROM `unit` 
WHERE (`Campuses` LIKE '%".$search."%') OR(`UnitID` LIKE '%".$search."%') OR(`UnitDescription` LIKE '%".$search."%') OR (`UnitName` LIKE '%".$search."%') OR (`Campuses` LIKE '%".$search."%')";
$result=$mysqli->query($query);

$result_cnt = $result->num_rows;

if ($result_cnt!=0){
    echo "We found ".$result_cnt." result(s)";
    while ($rows = mysqli_fetch_array($result)){
        ?>
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>UnitID</th>
                <th>Unit Name</th>
                <th>Unit Description</th>
                <th>Semester</th>
                <th>Campuses</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo $rows['UnitID']?></td>
                <td><?php echo $rows['UnitName']?></td>
                <td><?php echo $rows['UnitDescription']?></td>
                <td><?php echo $rows['OfferingSemester']?></td>
                <td><?php echo $rows['Campuses']?></td>
            </tr>
            </tbody>
        </table>
        <?php
    }
}else{
    echo 'nochange';
}

