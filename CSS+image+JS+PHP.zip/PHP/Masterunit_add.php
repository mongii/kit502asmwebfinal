<?php
include('../db_conn.php'); //db connection

header('Content-Type: application/json');



$mysqli = new mysqli('localhost', 'thyvo', '513579', 'thyvo');

if (mysqli_connect_errno()) {
    echo json_encode(array('mysqli' => 'Failed to connect to MySQL: ' . mysqli_connect_error()));
    exit;
}



$input = filter_input_array(INPUT_POST);
$id = mysqli_real_escape_string($mysqli,$input['UnitID']);
$unitName = mysqli_real_escape_string($mysqli,$input['UnitName']);
$unitDescription = mysqli_real_escape_string($mysqli,$input['UnitDescription']);
$semester = mysqli_real_escape_string($mysqli,$input['OfferingSemester']);
$campuses = mysqli_real_escape_string($mysqli,$input['Campuses']);

if ($input['action']=='edit'){
    $query ="UPDATE `unit` SET `UnitName`='$unitName',`UnitDescription`='$unitDescription',`OfferingSemester`='$semester',`Campuses`='$campuses' WHERE `UnitID`='$id'";
    $result = $mysqli->query($query);
}else if($input['action']=='delete'){
    $query = "DELETE FROM `unit` WHERE `UnitID`='$id'";
    $result=$mysqli->query($query);
}
mysqli_close($mysqli);

echo json_encode($input);