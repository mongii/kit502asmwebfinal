<?php
include('../db_conn.php');
include "session.php";
if($session_access!='student'){
    echo '
        <script>
            alert("You are not allowed to access this page!");
            window.history.back();
        </script>
    ';
}


//get the q parameter from URL
$unitCode=$_GET["code"];

$list_query = "DELETE FROM `unit_enrolled` WHERE UnitCode='$unitCode' AND username='$session_user'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);

$list_query = "SELECT * FROM `allocate` WHERE UnitCode='$unitCode' AND username='$session_user'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);
while($row= $result->fetch_array(MYSQLI_ASSOC)){
    $tuteCode=$row['tuteCode'];
    $query = "DELETE FROM `allocate` WHERE userrname='$session_user' AND tuteCode='$tuteCode'";
    $mysqli->query($query);

    $query = "UPDATE `classDetail` SET num=num-1 WHERE tuteCode='$tuteCode'";
    $mysqli->query($query);
}

echo '<script>alert("Successfully withdraw!")</script>';
?>
