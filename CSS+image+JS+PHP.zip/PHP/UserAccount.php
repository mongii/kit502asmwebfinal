<?php
include('../db_conn.php'); //db connection
include "session.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Master Staff</title>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="../js/jquery.tabledit.min.js"></script>
</head>
<body>
<script>
    
    $(document).ready(function (){
        $('#studentTable').Tabledit({
            url:'UserAccount_student_edit.php',
            columns:{
                identifier:[0,'ID'],
                editable:[[1,'username'],[2,'studentname'],[3,'email'],[4,'address'],[5,'dateofbirth'],[6,'phonenumber']]
            },
            restoreButton:false,
        })
    })
</script>
<script>
    $(document).ready(function (){
        $('#staffTable').Tabledit({
            url:'UserAccount_staff_edit.php',
            columns:{
                identifier:[0,'ID'],
                editable:[[1,'username'],[2,'staffname'],[3,'email'],[4,'degree'],[5,'professional'],[6,'phonenumber']]
            },
            restoreButton:false,
        })
    })
</script>

<body style="background-color: lavenderblush"
    <div class="container" id="bdiv">
    <header class="blog-header py-3">
    </div>

        <div class="row flex-nowrap justify-content-between align-items-center">
    <!--registration -->
            <!-- if user is not logged in, the registration button will be displayed  -->
            <?php
                include "session.php";
                    if ($session_user==""){
                        echo ' <div class="col-4 pt-1">
                                <a href="PHP/Registration.php" class="btn btn-success">Registration</a>
                               </div>';
                    }
                    ?>
            
            <div class="col-4 text-center">
                <h3 class="blog-header-logo text-dark" id="UDW">University of DoWell</h3>
            </div>
    <!--login & logout -->
            <!--the login button will be displayed if there is no login, and the logout button will be displayed if there is a login-->
            <div class="col-4 d-flex justify-content-end align-items-center">
                <?php
                if ($session_user==""){
                    echo'<a href="Login.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Login</a>';
                } else{
                    echo'<a href="LogOut.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Logout</a>';
                }
                ?>
            </div>
        </div>
    </header>

     <!-- navigation bar-->
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: black;">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <nav class="nav d-flex justify-content-between">
                <li class="navbar-brand">
                    <a class="nav-link" href="../Home.php">Home</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitDetail.php">Unit Detail</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitEnrollment.php">Unit Enrollment</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="IndividualTimetable.php">Individual Timetable</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="TutorialAllocation.php">Tutorial Allocation</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterList.php">Master List</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterStaff.php">Master Staff</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="EnrolledStudentDetails.php">Enrolled Student</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitManagement.php">Unit Management</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UserAccount.php">User Account</a>
                </li>
                </ul>
            </nav>
        </div>


    
    <div class="smalltron  text-black rounded bg-light" style="text-align:center">
        <div class="div2">
        </div>
        <div>
            <h1 class="display-7 font-italic">User Detail</h1>
        </div>
    </div>
</div>
<div class="container">
    <!--query for retrieving all the items from the Student table-->
    <?php
    $query="SELECT * FROM `Student` where `username`='$session_user'";
    $result=$mysqli->query($query);
    ?>

<table id="studentTable" class="table table-bordered table-striped" >
    <thead>
    <tr>
        <th>Student ID</th>
        <th>Username</th>
        <th>Student Name</th>
        <th>Email</th>
        <th>Address</th>
        <th>Date of Birth</th>
        <th>Phone Number</th>
    </tr>
    </thead>
    <tbody>

    <?php
    while ($rows = mysqli_fetch_array($result)){
        ?>
<!--extract the values, printing out with table-->
        <tr>
            <td><?php echo $rows['ID']?></td>
            <td><?php echo $rows['username']?></td>
            <td><?php echo $rows['studentname']?></td>
            <td><?php echo $rows['email']?></td>
            <td><?php echo $rows['address']?></td>
            <td><?php echo $rows['dateofbirth']?></td>
            <td><?php echo $rows['phonenumber']?></td>
        </tr>
    <?php  }
    ?>
    </tbody>
</table>
</div>

    <div class="container">
        <!--query for retrieving all the items from the Staff table-->
        <?php
        $query="SELECT * FROM `Staff` Where `username`='$session_user'";
        $result=$mysqli->query($query);
        ?>

        <table id="staffTable" class="table table-bordered table-striped" >
            <thead>
            <tr>
                <th>Staff ID</th>
                <th>Username</th>
                <th>Staff Name</th>
                <th>Email</th>
                <th>Degree</th>
                <th>Professional</th>
                <th>Phone Number</th>
            </tr>
            </thead>
            <tbody>

            <?php
            while ($rows = mysqli_fetch_array($result)){
                ?>
                <!--extract the values, printing out with table-->
                <tr>
                    <td><?php echo $rows['ID']?></td>
                    <td><?php echo $rows['username']?></td>
                    <td><?php echo $rows['staffname']?></td>
                    <td><?php echo $rows['email']?></td>
                    <td><?php echo $rows['degree']?></td>
                    <td><?php echo $rows['professional']?></td>
                    <td><?php echo $rows['phonenumber']?></td>
                </tr>
            <?php  }
            ?>
            </tbody>
        </table>
    </div>

<script>
    /*Retrieve the student or staff based on session_access*/
    var session_access="<?php echo $session_access?>";
        if(session_access=='student'){
            document.getElementById("studentTable").style.display="block";
            document.getElementById("staffTable").style.display="none";
        }else {
            document.getElementById("studentTable").style.display="none";
            document.getElementById("staffTable").style.display="block";
        }

</script>
</body>
 <!-- footer -->
 <footer align="center" style="font-weight: bold; background-color: white">
            <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
            <p>Copyright © 2020 Yen Vo. All right reserved. </p>
    </footer>


</html>
