<?php
include('../db_conn.php'); //db connection
include "Login_Validation.php";
include ('session.php');

if ($session_access!='DC' && $session_access!='UC' && $session_access!='tutor' && $session_access!='lecturer'){
    echo '
        <script>
            alert("You are not allowed to access this page!");
            window.history.back();
        </script>
    ';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enrolled Student Detail</title>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/home.css">
    <script src="../js/jquery.tabledit.min.js"></script>
</head>

<body style="background-color: lavenderblush"
    <div class="container" id="bdiv">
    <header class="blog-header py-3">
    </div>

        <div class="row flex-nowrap justify-content-between align-items-center">
    <!--registration -->
            <!-- if user is not logged in, the registration button will be displayed  -->
            <?php
                include "session.php";
                    if ($session_user==""){
                        echo ' <div class="col-4 pt-1">
                                <a href="PHP/Registration.php" class="btn btn-success">Registration</a>
                               </div>';
                    }
                    ?>
            
            <div class="col-4 text-center">
                <h3 class="blog-header-logo text-dark" id="UDW">University of DoWell</h3>
            </div>
    <!--login & logout -->
            <!--the login button will be displayed if there is no login, and the logout button will be displayed if there is a login-->
            <div class="col-4 d-flex justify-content-end align-items-center">
                <?php
                if ($session_user==""){
                    echo'<a href="Login.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Login</a>';
                } else{
                    echo'<a href="LogOut.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Logout</a>';
                }
                ?>
            </div>
        </div>
    </header>

     <!-- navigation bar-->
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: black;">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <nav class="nav d-flex justify-content-between">
                <li class="navbar-brand">
                    <a class="nav-link" href="../Home.php">Home</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitDetail.php">Unit Detail</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitEnrollment.php">Unit Enrollment</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="IndividualTimetable.php">Individual Timetable</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="TutorialAllocation.php">Tutorial Allocation</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterList.php">Master List</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterStaff.php">Master Staff</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="EnrolledStudentDetails.php">Enrolled Student</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitManagement.php">Unit Management</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UserAccount.php">User Account</a>
                </li>
                </ul>
            </nav>
        </div>


    <div class="smalltron  text-black rounded bg-light" style="text-align:center">
        <div>
            <h1 class="display-5 font-italic">Student Enrolled Detail</h1>
        </div>
    </div>
</div>
<div class="container">
<div id="tutor" class="container">
    <!--query for retrieving the items from the classDetail table according to username equal tutor-->
    <?php
    $query="SELECT * FROM `classDetail` WHERE `tutor`='$session_user'";
    $result=$mysqli->query($query);

   while ($row_tutorial=mysqli_fetch_array($result)){
       $tuteCode=$row_tutorial['tuteCode'];
       $query1="SELECT * FROM `allocate` WHERE `tuteCode`='$tuteCode'";
       $result1=$mysqli->query($query1);
     echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th> Tutorial Code </th>
        <th> Time </th>
        <th> Student Name </th>
      
    </tr>";

    while ($row_student = mysqli_fetch_array($result1)){
    ?>

    <tr>
        <td ><?php echo $row_tutorial['tuteCode']; ?></td>
        <td ><?php echo $row_tutorial['time']; ?></td>
        <td ><?php echo $row_student['username']; ?></td>
    </tr>
    <?php }

   }echo "</table>"
    ?>
</div>
<div id="lecturer" class="container">
    <?php
     /*query2 for retrieving the items from the unit table according to username equal lecturer*/
    $query2="SELECT * FROM `unit` WHERE  `lecturer`='$session_user'";
    $result2=$mysqli->query($query2);

    while ($row_unit=mysqli_fetch_array($result2)){
        $unitCode=$row_unit['UnitCode'];
        $query3="SELECT * FROM `unit_enrolled` WHERE `UnitCode`='$unitCode'";
        $result3=$mysqli->query($query3);
        echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th>Unit Code </th>
        <th>Time </th>
        <th>Student Name </th>
      
    </tr>";

        while ($row_unitstudent = mysqli_fetch_array($result3)){
            ?>

            <tr>
                <td ><?php echo $row_unitstudent['UnitCode']; ?></td>
                <td ><?php echo $row_unitstudent['time']; ?></td>
                <td ><?php echo $row_unitstudent['username']; ?></td>
            </tr>
        <?php }
    }echo "</table>"
    ?>
    <?php
    /*query4 for retrieving the items from the unit table according to username equal lecturer*/
    $query4="SELECT * FROM `unit` WHERE  `lecturer`='$session_user'";
    $result4=$mysqli->query($query4);

    while ($row_unit4=mysqli_fetch_array($result4)){
        $UnitCode=$row_unit4['UnitCode'];
        $query5="SELECT * FROM `allocate` WHERE `UnitCode`='$UnitCode'";
        $result5=$mysqli->query($query5);
        echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th >Tutorial Code</th>
        <th >Time</th>
        <th >Student Name</th>
      
    </tr>";

        while ($row_tutorial1 = mysqli_fetch_array($result5)){
            ?>

            <tr>
                <td ><?php echo $row_tutorial1['tuteCode']; ?></td>
                <td ><?php echo $row_tutorial1['time']; ?></td>
                <td ><?php echo $row_tutorial1['username']; ?></td>
            </tr>
        <?php }

    }echo "</table>"
    ?>
</div>
<div id="UC" class="container">
    <?php
    /*query6 for retrieving the items from the unit table according to username equal UC*/
    $query6="SELECT * FROM `unit` WHERE  `coordinator`='$session_user'";
    $result6=$mysqli->query($query6);

    while ($row_unit6=mysqli_fetch_array($result6)){
        $unitCode6=$row_unit6['UnitCode'];
        $query7="SELECT * FROM `unit_enrolled` WHERE `UnitCode`='$unitCode6'";
        $result7=$mysqli->query($query7);
        echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th >Unit Code</th>
        <th >Time</th>
        <th >Student Name</th>
      
    </tr>";

        while ($row_unitstudent7 = mysqli_fetch_array($result7)){
            ?>

            <tr>
                <td ><?php echo $row_unitstudent7['UnitCode']; ?></td>
                <td ><?php echo $row_unitstudent7['time']; ?></td>
                <td ><?php echo $row_unitstudent7['username']; ?></td>
            </tr>
        <?php }

    }echo "</table>"
    ?>
    <?php
    /*query8 for retrieving the items from the unit table according to username equal UC*/
    $query8="SELECT * FROM `unit` WHERE  `coordinator`='$session_user'";
    $result8=$mysqli->query($query8);

    while ($row_unit8=mysqli_fetch_array($result8)){
        $UnitCode8=$row_unit8['UnitCode'];
        $query9="SELECT * FROM `allocate` WHERE `UnitCode`='$UnitCode8'";
        $result9=$mysqli->query($query9);
        echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th >Tutorial Code</th>
        <th >Time</th>
        <th >Student Name</th>
      
    </tr>";

        while ($row_studenttute = mysqli_fetch_array($result9)){
            ?>

            <tr>
                <td ><?php echo $row_studenttute['tuteCode']; ?></td>
                <td ><?php echo $row_studenttute['time']; ?></td>
                <td ><?php echo $row_studenttute['username']; ?></td>
            </tr>
        <?php }

    }echo "</table>"
    ?>
</div>
<div id="DC" class="container">
    <?php
    /*query10 for retrieving all the items from the unit table */
    $query10="SELECT * FROM `unit` ";
    $result10=$mysqli->query($query10);

    while ($row_unit10=mysqli_fetch_array($result10)){
        $unitCode10=$row_unit10['UnitCode'];
        $query11="SELECT * FROM `unit_enrolled` WHERE `UnitCode`='$unitCode10'";
        $result11=$mysqli->query($query11);
        echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th >Unit Code</th>
        <th >Time</th>
        <th >Student Name</th>
      
    </tr>";

        while ($row_unitstudent11 = mysqli_fetch_array($result11)){
            ?>

            <tr>
                <td ><?php echo $row_unitstudent11['UnitCode']; ?></td>
                <td ><?php echo $row_unitstudent11['time']; ?></td>
                <td ><?php echo $row_unitstudent11['username']; ?></td>
            </tr>
        <?php }

    }echo "</table>"
    ?>
    <?php
    /*query12 for retrieving all the items from the classDetail table*/
    $query12="SELECT * FROM `classDetail` ";
    $result12=$mysqli->query($query12);

    while ($row_tutorial12=mysqli_fetch_array($result12)){
        $tuteCode12=$row_tutorial12['tuteCode'];
        $query13="SELECT * FROM `allocate` WHERE `tuteCode`='$tuteCode12'";
        $result13=$mysqli->query($query13);
        echo"
    <table class='table table-bordered table-striped '>
    <tr>
        <th >Tutorial Code</th>
        <th >Time</th>
        <th >Student Name</th>
      
    </tr>";

        while ($row_student13 = mysqli_fetch_array($result13)){
            ?>

            <tr>
                <td ><?php echo $row_student13['tuteCode']; ?></td>
                <td ><?php echo $row_student13['time']; ?></td>
                <td ><?php echo $row_student13['username']; ?></td>
            </tr>
        <?php }

    }echo "</table>"
    ?>
</div>
</div>

<script>
    /* session access */
    var session_access="<?php echo $session_access?>";
    if(session_access=='tutor'){
        document.getElementById("tutor").style.display="block";
        document.getElementById("lecturer").style.display="none";
        document.getElementById("UC").style.display="none";
        document.getElementById("DC").style.display="none";
    }else if(session_access=='lecturer') {
        document.getElementById("tutor").style.display="none";
        document.getElementById("lecturer").style.display="block";
        document.getElementById("UC").style.display="none";
        document.getElementById("DC").style.display="none";
    }else if(session_access=='UC') {
        document.getElementById("tutor").style.display="none";
        document.getElementById("lecturer").style.display="none";
        document.getElementById("UC").style.display="block";
        document.getElementById("DC").style.display="none";
    } else if(session_access=='DC') {
        document.getElementById("tutor").style.display="none";
        document.getElementById("lecturer").style.display="none";
        document.getElementById("UC").style.display="none";
        document.getElementById("DC").style.display="block";
    }
</script>


</body>
<!-- footer -->
<footer align="center" style="font-weight: bold; background-color: white">
            <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
            <p>Copyright © 2020 Yen Vo. All right reserved. </p>
</footer>

</html>
