<?php

include('../db_conn.php'); //db connection
include "Login_Validation.php";
include "session.php";

if ($session_access != 'student') {
    echo '
        <script>
            alert("You do not have access to this page!");
            window.history.back();
        </script>
    ';
}


//get the q parameter from URL
$unitCode=$_GET["unitCode"];
$tuteCode=$_GET["tuteCode"];

$list_query = "DELETE FROM `allocate` WHERE tuteCode='$tuteCode' AND username='$session_user'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);

$list_query = "UPDATE `classDetail` SET num=num-1 WHERE tuteCode='$tuteCode'";
//execute the query 'list_query'
$result= $mysqli->query($list_query);
?>