<?php
include('../db_conn.php'); //db connection

header('Content-Type: application/json');



$mysqli = new mysqli('localhost', 'thyvo', '513579', 'thyvo');

if (mysqli_connect_errno()) {
    echo json_encode(array('mysqli' => 'Failed to connect to MySQL: ' . mysqli_connect_error()));
    exit;
}



$input = filter_input_array(INPUT_POST);
$UnitCode = mysqli_real_escape_string($mysqli,$input['UnitCode']);
$time = mysqli_real_escape_string($mysqli,$input['time']);
$consultation = mysqli_real_escape_string($mysqli,$input['consultation']);
$Campuses = mysqli_real_escape_string($mysqli,$input['Campuses']);

if ($input['action']=='edit'){
    $query ="UPDATE `unit` SET `time`='$time',`consultation`='$consultation',`Campuses`='$Campuses' WHERE `UnitCode`='$UnitCode'";
    $result = $mysqli->query($query);
}else if($input['action']=='delete'){
    $query = "DELETE FROM `classDetail` WHERE `UnitCode`='$UnitCode'";
    $result=$mysqli->query($query);
}
mysqli_close($mysqli);

echo json_encode($input);
