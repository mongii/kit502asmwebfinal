<?php
include('../db_conn.php'); //db connection

header('Content-Type: application/json');



$mysqli = new mysqli('localhost', 'thyvo', '513579', 'thyvo');

if (mysqli_connect_errno()) {
    echo json_encode(array('mysqli' => 'Failed to connect to MySQL: ' . mysqli_connect_error()));
    exit;
}



$input = filter_input_array(INPUT_POST);
$ID = mysqli_real_escape_string($mysqli,$input['ID']);
$username = mysqli_real_escape_string($mysqli,$input['username']);
$staffname = mysqli_real_escape_string($mysqli,$input['staffname']);
$email = mysqli_real_escape_string($mysqli,$input['email']);
$degree = mysqli_real_escape_string($mysqli,$input['degree']);
$professional = mysqli_real_escape_string($mysqli,$input['professional']);
$phonenumber = mysqli_real_escape_string($mysqli,$input['phonenumber']);


if ($input['action']=='edit'){
    $query ="UPDATE `Staff` SET `username`='$username',`staffname`='$staffname',`email`='$email',`degree`='$degree',`professional`='$phonenumber' WHERE `ID`='$ID'";
    $result = $mysqli->query($query);
}else if($input['action']=='delete'){
    $query = "DELETE FROM `Staff` WHERE `ID`='$ID'";
    $result=$mysqli->query($query);
}
mysqli_close($mysqli);

echo json_encode($input);

