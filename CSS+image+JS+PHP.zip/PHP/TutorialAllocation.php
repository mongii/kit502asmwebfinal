<?php
include('../db_conn.php'); //db connection
include "Login_Validation.php";
include "session.php";

if($session_access!='student'){
    echo '
        <script>
            alert("You do not have access to this page!");
            window.history.back();
        </script>
    ';
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Tutorial Allocation</title>
        <script type="text/javascript"  src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
        <link rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
              integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/home.css">
    </head>
    <script type="text/JavaScript">
        // when user clicks the check button id='check', execute the following function

       function list(){

            var unitCode = $("#states").val().substring(0, 6);

            $.get( "TutorialAllocation_list.php", {unitCode: unitCode} )
                .done(function(data) {

                    $("#output").html(data);
                });
        }

        // when user clicks the check button id='check', execute the following function
        function follow() {

            var unitCode = $("#suburbs:checked").attr("name");
            var tuteCode = $("#suburbs:checked").val();

            $.get( "TutorialAllocation_enrol.php", {unitCode: unitCode, tuteCode:tuteCode} )
                .done(function( data ) {

                    alert('Successfully allocated!');
                    location.reload();
                });
        }

        // when user clicks the check button id='check', execute the following function
        function unallocate() {

            var unitCode = $("#tute_withdraw:checked").val().substring(0, 6);
            var tuteCode = $("#tute_withdraw:checked").val().substring(7);

            $.get( "TutorialAllocation_withdraw.php", {unitCode: unitCode, tuteCode:tuteCode} )
                .done(function( data ) {

                    alert('Unallocated!');
                    location.reload();
                });
        }
    </script>
    <body>
    <div class="container" id="bdiv">
        <!-- nav bar-->
        <header class="blog-header py-3">
            <div class="row flex-nowrap justify-content-between align-items-center">
                <!--registration button-->
                <!--Judgment: if not logged in the registration button will be displayed  -->
                <?php
                if ($session_user==""){
                    echo ' <div class="col-4 pt-1">
                                <a href="Registration.php" class="btn btn-sm btn-outline-secondary">Registration</a>
                               </div>';
                }
                ?>
                <div class="col-4 text-center">
                    <h3 class="blog-header-logo text-dark" id="UDW">University of DoWell</h3>
                </div>
                <!--login and logout button-->
                <!--Judgment: the login button will be displayed if there is no login, and the logout button will be displayed if there is login-->
                <div class="col-4 d-flex justify-content-end align-items-center">
                    <?php
                    if ($session_user==""){
                        echo'<a href="Login.php" class="btn btn-sm btn-outline-secondary">Login</a>';
                    } else{
                        echo'<a href="LogOut.php" class="btn btn-sm btn-outline-secondary">Logout</a>';
                    }
                    ?>
                </div>
            </div>
        </header>
        <div class="nav-scroller py-1 mb-2">
            <nav class="nav d-flex justify-content-between">
                <a class="p-2 text-muted" href="../Home.php">Home</a>
                <a class="p-2 text-muted" href="UnitDetail.php">Unit Detail</a>
                <a class="p-2 text-muted" href="UnitEnrollment.php">Unit Enrollment</a>
                <a class="p-2 text-muted" href="IndividualTimetable.php">Individual Timetable</a>
                <a class="p-2 text-muted" href="TutorialAllocation.php">Tutorial Allocation</a>
                <a class="p-2 text-muted" href="MasterList.php">Master Unit</a>
                <a class="p-2 text-muted" href="MasterStaff.php">Master Staff</a>
                <a class="p-2 text-muted" href="EnrolledStudentDetails.php">Enrolled Student</a>
                <a class="p-2 text-muted" href="UnitManagement.php">Unit Management</a>
                <a class="p-2 text-muted" href="UserAccount.php">User Account</a>
            </nav>
        </div>
        <div class="jumbotron  text-white rounded bg-dark">
            <div class="div2">
                <img src="../image/picture10.jpg">
            </div>
            <div>
                <h1 class="display-5 font-italic">Tutorial Allocation System</h1>
            </div>
        </div>
    </div>
    <div class ="container">
        <select name="states" id="states" class="form-control" onchange="list()">
            <option value="None" selected>Please select an unit to allocate a tutorial</option>
            <?php
            //query for retreiving all the items from the unit table
            $list_query = "SELECT * FROM unit";

            $result= $mysqli->query($list_query);
            $result_cnt = $result->num_rows;

            while($row= $result->fetch_array(MYSQLI_ASSOC)){

                //extract the values
                $unitCode=$row['UnitCode'];
                $unitName=$row['UnitName'];
                $Semester=$row['OfferingSemester'];
                $campuse=$row['Campuses'];

                //printing out with table :)
                echo("<option value='$unitCode $unitName'>$unitCode $unitName</option>");
            }
            ?>
        </select>
        <div id="output"></div>
        <?php
        //query for retrieving all the items from the allocate table
        $list_query = "SELECT * FROM `allocate` WHERE username='$session_user'";

        $result= $mysqli->query($list_query);
        $result_cnt = $result->num_rows;
        if($result_cnt!=0)
        {
            echo '<table class="table table-striped table-sm">
				  <thead>
					<tr>
					  <th>Unit code</th>
					  <th>Tutorial code</th>
					  <th>Time</th>
					  <th>withdraw</th>
					</tr>
				  </thead>
				  <tbody>
				  <h3>Tutorial Allocated<h3>';

            $i=1;
            while($row= $result->fetch_array(MYSQLI_ASSOC)){

                //extract the values
                $unitCode=$row['UnitCode'];
                $tuteCode=$row['tuteCode'];
                $time=$row['time'];
                if($i==1)

                //printing out with table :)
                {
                    echo ("<tr><td>$unitCode</td>
                           <td>$tuteCode</td>
						    <td>$time</td>
                         <td><input type='radio' id='tute_withdraw' name='tute' value='$unitCode $tuteCode' checked></td></tr>");
                }
                else
                {
                    echo ("<tr><td>$unitCode</td>
                              <td>$tuteCode</td>
							    <td>$time</td>
                              <td><input type='radio' id='tute_withdraw' name='tute' value='$unitCode $tuteCode'></td></tr>");
                }
                $i=$i+1;
            }
            echo "
				</tbody>
			</table>
			<button type='button' class='btn btn-primary' onclick='unallocate()'>Withdraw</button>";
        }
        ?>
    </div>

        <div class="table-responsive" id="output">
        </div>
    <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
    </body>
</html>