<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Registration</title>
        <script type="text/javascript"  src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
        <link rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
              integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <script src="../js/registration.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/registration.css">
    </head>
    <body style="background-color: lavenderblush"
    <div class="container" id="bdiv">
    <header class="blog-header py-3">
    </div>
  
    <!-- nav bar-->
    <nav class="nav bg-light shadow-sm">
        <div>
            <a class="nav-brand" href="../Home.php">
                <img src="../image/logo.png" id="Logo">
                Back to the Main Page
            </a>
        </div>

    <!--   Tab pane-->
    <div class="container">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link" active data-toggle="tab" href="#student">Student</a>
            </li>
            <li class="nav-item">
                <a class="nav-link"  data-toggle="tab" href="#staff">Staff</a>
            </li>
        </ul>
        <!--Student form-->
        <div class="tab-content">
            <div id="student" class="container tab-pane active">
                <form class="form-signin" onsubmit="return stuvalidation();" method="post" action="Registrationstudent_process.php">
                    <h4>I am a student</h4>
                    <br>Username <div class="input-group">
                        <input type="text" name="username" id="name"  class="form-control" placeholder="Username">
                    </div> 
                    <br>Student Name <div class="input-group">
                        <input type="text" name="studentname" id="studentname"  class="form-control" placeholder="StudentName">
                    </div>
                    <br>Password <div class="input-group">
                        <input type="password" name="password" id="password"  class="form-control" placeholder="Password">
                    </div>
                    <br>Confirm password <div class="input-group">
                        <input type="password"  id="Confirm_password"  class="form-control" placeholder="Confirmpassword">
                    </div>
                    <br>Email <div class="input-group">
                        <input type="email" name="email" id="email"  class="form-control" placeholder="Email">
                    </div>
                    <br>Address <div class="input-group">
                        <input type="text" name="address" id="address"  class="form-control" placeholder="Address">
                    </div>
                    <br>Date of birth <div class="input-group">
                        <input type="date" name="dateofbirth" id="birth"  class="form-control" placeholder="Date of Birth">
                    </div>
                    <br>Phone Number <div class="input-group">
                        <input type="text" name="phonenumber" id="phonenumber"  class="form-control" placeholder="Phone number">
                    </div>
                    <br> <button  class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                </form>
            </div>
            <!--  staff form-->
            <div id="staff" class="container tab-pane fade">
                <form class="form-signin" onsubmit="return stavalidation();" method="post" action="Registrationstaff_process.php">
                    <h4>I am a staff</h4>
                    <br>Username <div class="input-group">
                            <input type="text" name="username" id="name"  class="form-control" placeholder="Username">
                        </div>
                    <br>Staff Name <div class="input-group">
                        <input type="text" name="staffname" id="staffName"  class="form-control" placeholder="StaffName">
                    </div>
                    <br>Password <div class="input-group">
                        <input type="password" name="password" id="staffpassword"  class="form-control" placeholder="Password">
                    </div>
                    <br>Confirm Password <div class="input-group">
                        <input type="password" id="staffConfirm_password"  class="form-control" placeholder="Confirmpassword">
                    </div>
                    <br>Email <div class="input-group">
                        <input type="email" name="email" id="staffemail"  class="form-control" placeholder="Email">
                    </div>
                    <br> Choose your option <div class="input-group form-control">
                        Degree:<select class="form-control" id="qualification" name="degree">
                            <option></option>
                            <option value="Bachelor">Bachelor</option>
                            <option value="Master">Master</option>
                            <option value="PhD">PhD</option>
                        </select>
                    </div>
                    <br><div class="input-group form-control">
                        Professional:<select class="form-control" id="expertise" name="professional">
                            <option></option>
                            <option value="InformationSystem">Information Systems</option>
                            <option value="HumanComputer">Human Computer Interaction</option>
                            <option value="NetworkAdministration">Civil Engineering</option>
                            <option value="NetworkAdministration">Mobile Development</option>
                            <option value="NetworkAdministration">Finance </option>
                            <option value="NetworkAdministration">Maths</option>
                        </select>
                    </div>
                    <br>Phone Number <div class="input-group">
                        <input type="text" name="phonenumber" id="staffphonenumber"  class="form-control" placeholder="Phone number">
                    </div>
                    <button  class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>
    
    </body>
    <!-- footer -->
    <footer align="center" style="font-weight: bold; background-color: white">
            <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
            <p>Copyright © 2020 Yen Vo. All right reserved. </p>
    </footer>
</html>