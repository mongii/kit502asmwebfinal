<?php
include('../db_conn.php');
include ('session.php');
$username=$_POST['username'];
$staffname=$_POST['staffname'];
$password=$_POST['password'];
$email=$_POST['email'];
$degree=$_POST['degree'];
$professional=$_POST['professional'];
$phonenumber=$_POST['phonenumber'];

$encrypted_password=crypt($password,'salt');


$query = "SELECT * FROM `Staff` WHERE `username`= '$username'";
$result=$mysqli->query($query);
$result_cunt=$result->num_rows;
if ($result_cunt=="0"){

    $query="INSERT INTO `Staff`(`username`,`staffname`, `password`, `email`, `degree`, `professional`, `phonenumber`, `accesslevel`) 
                     VALUES ('$username','$staffname','$encrypted_password','$email','$degree','$professional','$phonenumber','staff')";
    $result=$mysqli->query($query);
    echo '<script>alert("Sign up successfully!")</script>';
    $_SESSION['session_user']=$username;
    $_SESSION['session_access']='staff';

    header('Home.php');
}else{
    echo '<script>
         alert("Username Exists!");
         window.history.back();
         </script>';
}
