<?php
include('../db_conn.php'); //db connection
include "Login_Validation.php";
include ("session.php");

if ($session_access!='DC' && $session_access!='UC'){
    echo '
        <script>
            alert("You do not have access to this page!");
            window.history.back();
        </script>
    ';
}

?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Unit Management</title>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <link rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
              integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/home.css">
        <script src="../js/jquery.tabledit.min.js"></script>

    </head>
        <body>
        <script>
            // when UC clicks the click confirm button, execute the following function for lecturer
            $(document).ready(function(){
                $("#AcademicStaff").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(0)").text(); 

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_lecturer_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            // when UC clicks the click confirm button, execute the following function for tutor
            $(document).ready(function(){
                $("#AcademicStaff_tutor").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(1)").text();

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_tutor_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            $(document).ready(function (){
                $('#tabledit').Tabledit({
                    url:'UnitManagement_lecture_edit.php',
                    columns:{
                        identifier:[0,'UnitCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Campuses']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            $(document).ready(function (){
                $('#tabledit1').Tabledit({
                    url:'UnitManagement_tutorial_edit.php',
                    columns:{
                        identifier:[0,'tuteCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Room']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            // when UC1 clicks the click confirm button, execute the following function for lecturer
            $(document).ready(function(){
                $("#AcademicStaff1").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(0)").text(); 

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_lecturer1_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            // when UC1 clicks the click confirm button, execute the following function for tutor
            $(document).ready(function(){
                $("#AcademicStaff_tutor1").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(1)").text();

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_tutor1_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            $(document).ready(function (){
                $('#tableditUC1').Tabledit({
                    url:'UnitManagement_lecture1_edit.php',
                    columns:{
                        identifier:[0,'UnitCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Campuses']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            $(document).ready(function (){
                $('#tableditUC11').Tabledit({
                    url:'UnitManagement_tutorial1_edit.php',
                    columns:{
                        identifier:[0,'tuteCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Room']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            // when UC2 clicks the click confirm button, execute the following function for lecturer
            $(document).ready(function(){
                $("#AcademicStaff2").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(0)").text(); //获得当前行第二个TD值

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_lecturer2_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            // when UC2 clicks the click confirm button, execute the following function for tutor
            $(document).ready(function(){
                $("#AcademicStaff_tutor2").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(1)").text();

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_tutor2_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            $(document).ready(function (){
                $('#tableditUC2').Tabledit({
                    url:'UnitManagement_lecture2_edit.php',
                    columns:{
                        identifier:[0,'UnitCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Campuses']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            $(document).ready(function (){
                $('#tableditUC21').Tabledit({
                    url:'UnitManagement_tutorial2_edit.php',
                    columns:{
                        identifier:[0,'tuteCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Room']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            // when UC3 clicks the click confirm button, execute the following function for lecturer
            $(document).ready(function(){
                $("#AcademicStaff3").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(0)").text(); 

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_lecturer3_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            // when UC3 clicks the click confirm button, execute the following function for tutor
            $(document).ready(function(){
                $("#AcademicStaff_tutor3").on('click','.Confirm',function(){
                    var currentRow=$(this).closest("tr");
                    var col1=currentRow.find("td:eq(1)").text();

                    var col2=currentRow.find("td:eq(3)").children().val();
                    $.get('UnitManagement_tutor3_process.php',{col1:col1, col2:col2})
                        .done(function(data){
                            alert(data);
                            location.reload();
                        });
                });
            });
        </script>
        <script>
            $(document).ready(function (){
                $('#tableditUC3').Tabledit({
                    url:'UnitManagement_lecture3_edit.php',
                    columns:{
                        identifier:[0,'UnitCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Campuses']]
                    },
                    restoreButton:false,
                })
            })
        </script>
        <script>
            $(document).ready(function (){
                $('#tableditUC31').Tabledit({
                    url:'UnitManagement_tutorial3_edit.php',
                    columns:{
                        identifier:[0,'tuteCode'],
                        editable:[[1,'time'],[2,'consultation'],[3,'Room']]
                    },
                    restoreButton:false,
                })
            })
        </script>

            <div class="container" id="bdiv">
                <header class="blog-header py-3">
                    <div class="row flex-nowrap justify-content-between align-items-center">
                        <!--registration button-->
                        <!--Judgment: if not logged in the registration button will be displayed  -->
                        <?php
                        if ($session_user==""){
                            echo ' <div class="col-4 pt-1">
                                        <a href="Registration.php" class="btn btn-sm btn-outline-secondary">Registration</a>
                                       </div>';
                        }
                        ?>
                        <div class="col-4 text-center">
                            <h3 class="blog-header-logo text-dark" id="UDW">University of DoWell</h3>
                        </div>
                        <!--login and logout button-->
                        <!--Judgment: the login button will be displayed if there is no login, and the logout button will be displayed if there is login-->
                        <div class="col-4 d-flex justify-content-end align-items-center">
                            <?php
                            if ($session_user==""){
                                echo'<a href="Login.php" class="btn btn-sm btn-outline-secondary">Login</a>';
                            } else{
                                echo'<a href="LogOut.php" class="btn btn-sm btn-outline-secondary">Logout</a>';
                            }
                            ?>
                        </div>
                    </div>
                </header>
                <div class="nav-scroller py-1 mb-2">
                    <nav class="nav d-flex justify-content-between">
                        <a class="p-2 text-muted" href="../Home.php">Home</a>
                        <a class="p-2 text-muted" href="UnitDetail.php">Unit Detail</a>
                        <a class="p-2 text-muted" href="UnitEnrollment.php">Unit Enrollment</a>
                        <a class="p-2 text-muted" href="IndividualTimetable.php">Individual Timetable</a>
                        <a class="p-2 text-muted" href="TutorialAllocation.php">Tutorial Allocation</a>
                        <a class="p-2 text-muted" href="MasterList.php">Master Unit</a>
                        <a class="p-2 text-muted" href="MasterStaff.php">Master Staff</a>
                        <a class="p-2 text-muted" href="EnrolledStudentDetails.php">Enrolled Student</a>
                        <a class="p-2 text-muted" href="UnitManagement.php">Unit Management</a>
                        <a class="p-2 text-muted" href="UserAccount.php">User Account</a>

                    </nav>
                </div>
                <div class="jumbotron  text-white rounded bg-dark">
                    <div class="div2">
                        <img src="../image/picture9.png">
                    </div>
                    <div>
                        <h1 class="display-5 font-italic">Unit Management</h1>
                    </div>
                </div>
            </div>
        <div class="container">
            <!--   Tab pane-->
            <ul class="nav nav-tabs" role="tablist">
                <?php
                        if ($session_user=="yUC"){
               echo ' <li class="nav-item">
                    <a class="nav-link" active data-toggle="tab" href="#yUC">Please Click here: yUC</a>
                </li>';
                        }
               else if ($session_user=="yUC1"){
                   echo '<li class="nav-item">
                    <a class="nav-link"  data-toggle="tab" href="#yUC1">Please Click here: yUC1</a>
                </li>';
                        }
               else if ($session_user=="yUC2"){
                   echo '<li class="nav-item">
                    <a class="nav-link"  data-toggle="tab" href="#yUC2">Please Click here: yUC2</a>
                </li>';
               } else if ($session_user=="yUC3"){
                   echo '<li class="nav-item">
                    <a class="nav-link"  data-toggle="tab" href="#yUC3">Please Click here: yUC3</a>
                </li>';
               }else{
                   echo ('');
               }

                ?>
            </ul>
            <div class="tab-content">
                <div id="yUC" class="container tab-pane ">
                    <?php
                    echo 'Welcome, yUC !';
                    ?>
                    <br>
                    <h4 align ="left">Allocate lecturers </h4>
                    <!--query for retrieving all the items from the unit table-->
                    <?php
                    $query="SELECT * FROM `unit` Where `coordinator`='yUC'";
                    $result_unit=$mysqli->query($query);
                    ?>

                    <table id="AcademicStaff" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Unit Code</th>
                            <th>Unit Name</th>
                            <th>Current Lecturer</th>
                            <th>Lecturer</th>
                            <th>Confirm</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                        while ($rows = mysqli_fetch_array($result_unit)){
                            ?>
                            <!--extract the values, printing out with table-->
                            <tr>
                                <td><?php echo $rows['UnitCode']?></td>
                                <td><?php echo $rows['UnitName']?></td>
                                <td><?php echo $rows['Lecturer']?></td>
                                <td>
                                    <select id="<?php echo $rows['UnitCode']?>">

                                        <?php
                                        //echo $rows['Lecturer']
                                        $query="SELECT * FROM `Staff` WHERE `Code`='KIT234' ";
                                        $result_Staff=$mysqli->query($query);

                                        while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                            ?>
                                            <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];    ?></option>
                                            <?php
                                        }

                                        ?>
                                    </select>

                                </td>
                                <td><button  class="btn btn-success Confirm">Confirm</button></td>
                            </tr>
                        <?php  }
                        ?>
                        </tbody>
                    </table>
                        <h4 align ="left">Allocate tutors </h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` Where `UnitCode`='KIT234'";
                        $result_unit=$mysqli->query($query);

                        ?>

                        <table id="AcademicStaff_tutor" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Tutorial Code</th>
                                <th>Current Tutor</th>
                                <th>Tutor</th>
                                <th>Confirm</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result_unit)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['tutor']?></td>
                                    <td>
                                        <select id="<?php echo $rows['UnitCode']?>">
                                            <?php
                                            //echo $rows['Lecturer']
                                            $query="SELECT * FROM `Staff` WHERE `Code`='KIT403_tutor'";
                                            $result_Staff=$mysqli->query($query);

                                            while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                                ?>
                                                <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];?></option>
                                                <?php
                                            }

                                            ?>

                                        </select>

                                    </td>
                                    <td><button  class="btn btn-success Confirm">Confirm</button></td>
                                </tr>
                            <?php  }
                            ?>
                            </tbody>
                        </table>

                        <h4 align ="left">Change the unit details</h4>
                        <!--query for retrieving all the items from the unit table-->
                        <?php
                        $query="SELECT * FROM `unit` WHERE `coordinator`='yUC'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tabledit" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Campuses']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                        <h4 align ="left">Change tutorials details</h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` WHERE `UnitCode`='KIT403'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tabledit1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Tutorial Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Room']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                </div>
                <div id="yUC1" class="container tab-pane">
                    <?php
                    echo 'Welcome ';
                    ?>
                    <h4 align ="left">Allocate lecturers </h4>
                    <!--query for retrieving all the items from the unit table-->
                    <?php
                    $query="SELECT * FROM `unit` Where `coordinator`='yUC1'";
                    $result_unit=$mysqli->query($query);

                    ?>

                    <table id="AcademicStaff1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Unit Code</th>
                            <th>Unit Name</th>
                            <th>Current Lecturer</th>
                            <th>Lecturer</th>
                            <th>Confirm</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                        while ($rows = mysqli_fetch_array($result_unit)){
                            ?>
                            <!--extract the values, printing out with table-->
                            <tr>
                                <td><?php echo $rows['UnitCode']?></td>
                                <td><?php echo $rows['UnitName']?></td>
                                <td><?php echo $rows['Lecturer']?></td>
                                <td>
                                    <select id="<?php echo $rows['UnitCode']?>">

                                        <?php
                                        //echo $rows['Lecturer']
                                        $query="SELECT * FROM `Staff` WHERE `Code`='KIT403' ";
                                        $result_Staff=$mysqli->query($query);

                                        while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                            ?>
                                            <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];    ?></option>
                                            <?php
                                        }

                                        ?>
                                    </select>

                                </td>
                                <td><button  class="btn btn-success Confirm">Confirm</button></td>
                            </tr>
                        <?php  }
                        ?>
                        </tbody>
                    </table>
                    <div>
                        <h4 align ="left">Allocate tutors </h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` Where `UnitCode`='KIT403'";
                        $result_unit=$mysqli->query($query);

                        ?>

                        <table id="AcademicStaff_tutor1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Tutorial Code</th>
                                <th>Current Tutor</th>
                                <th>Tutor</th>
                                <th>Confirm</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result_unit)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['tutor']?></td>
                                    <td>
                                        <select id="<?php echo $rows['UnitCode']?>">
                                            <?php
                                            //echo $rows['Lecturer']
                                            $query="SELECT * FROM `Staff` WHERE `Code`='KIT403_tutor'";
                                            $result_Staff=$mysqli->query($query);

                                            while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                                ?>
                                                <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];?></option>
                                                <?php
                                            }

                                            ?>

                                        </select>

                                    </td>
                                    <td><button  class="btn btn-success Confirm">Confirm</button></td>
                                </tr>
                            <?php  }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <h4 align ="left">Change the unit details</h4>
                        <!--query for retrieving all the items from the unit table-->
                        <?php
                        $query="SELECT * FROM `unit` WHERE `coordinator`='yUC1'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tableditUC1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Campuses']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <h4 align ="left">Change tutorials details</h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` WHERE `UnitCode`='KIT403'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tableditUC11" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Tutorial Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Room']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div id="yUC2" class="container tab-pane ">
                    <?php
                    echo 'Welcome, yUC2 !';
                    ?>
                    <br>
                    <h4 align ="left">Allocate lecturers </h4>
                    <!--query for retrieving all the items from the unit table-->
                    <?php
                    $query="SELECT * FROM `unit` Where `coordinator`='yUC2'";
                    $result_unit=$mysqli->query($query);

                    ?>

                    <table id="AcademicStaff2" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Unit Code</th>
                            <th>Unit Name</th>
                            <th>Current Lecturer</th>
                            <th>Lecturer</th>
                            <th>Confirm</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                        while ($rows = mysqli_fetch_array($result_unit)){
                            ?>
                            <!--extract the values, printing out with table-->
                            <tr>
                                <td><?php echo $rows['UnitCode']?></td>
                                <td><?php echo $rows['UnitName']?></td>
                                <td><?php echo $rows['Lecturer']?></td>
                                <td>
                                    <select id="<?php echo $rows['UnitCode']?>">

                                        <?php
                                        $query="SELECT * FROM `Staff` WHERE `Code`='ENG405' ";
                                        $result_Staff=$mysqli->query($query);

                                        while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                            ?>
                                            <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];    ?></option>
                                            <?php
                                        }

                                        ?>
                                    </select>

                                </td>
                                <td><button  class="btn btn-success Confirm">Confirm</button></td>
                            </tr>
                        <?php  }
                        ?>
                        </tbody>
                    </table>
                    <div>
                        <h4 align ="left">Allocate tutors </h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` Where `UnitCode`='ENG405'";
                        $result_unit=$mysqli->query($query);

                        ?>

                        <table id="AcademicStaff_tutor2" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Tutorial Code</th>
                                <th>Current Tutor</th>
                                <th>Tutor</th>
                                <th>Confirm</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result_unit)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['tutor']?></td>
                                    <td>
                                        <select id="<?php echo $rows['UnitCode']?>">
                                            <?php
                                            $query="SELECT * FROM `Staff` WHERE `Code`='ENG405_tutor'";
                                            $result_Staff=$mysqli->query($query);

                                            while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                                ?>
                                                <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];?></option>
                                                <?php
                                            }

                                            ?>

                                        </select>

                                    </td>
                                    <td><button  class="btn btn-success Confirm">Confirm</button></td>
                                </tr>
                            <?php  }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <h4 align ="left">Change the unit details</h4>
                        <!--query for retrieving all the items from the unittable-->
                        <?php
                        $query="SELECT * FROM `unit` WHERE `coordinator`='yUC2'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tableditUC2" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Campuses']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <h4 align ="left">Change tutorials details</h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` WHERE `UnitCode`='BUSM303'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tableditUC21" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Tutorial Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Room']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div id="yUC3" class="container tab-pane">
                    <?php
                    echo 'Welcome !';
                    ?>
                    <br>
                    <h4 align ="left">Allocate lecturers </h4>
                    <!--query for retrieving all the items from the unit table-->
                    <?php
                    $query="SELECT * FROM `unit` Where `coordinator`='yUC3'";
                    $result_unit=$mysqli->query($query);

                    ?>

                    <table id="AcademicStaff3" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Unit Code</th>
                            <th>Unit Name</th>
                            <th>Current Lecturer</th>
                            <th>Lecturer</th>
                            <th>Confirm</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                        while ($rows = mysqli_fetch_array($result_unit)){
                            ?>
                            <!--extract the values, printing out with table-->
                            <tr>
                                <td><?php echo $rows['UnitCode']?></td>
                                <td><?php echo $rows['UnitName']?></td>
                                <td><?php echo $rows['Lecturer']?></td>
                                <td>
                                    <select id="<?php echo $rows['UnitCode']?>">

                                        <?php

                                        $query="SELECT * FROM `Staff` WHERE `Code`='KIT111' ";
                                        $result_Staff=$mysqli->query($query);

                                        while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                            ?>
                                            <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];    ?></option>
                                            <?php
                                        }

                                        ?>
                                    </select>

                                </td>
                                <td><button  class="btn btn-success Confirm">Confirm</button></td>
                            </tr>
                        <?php  }
                        ?>
                        </tbody>
                    </table>
                    <div>
                        <h4 align ="left">Allocate tutors </h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` Where `UnitCode`='BUSM303'";
                        $result_unit=$mysqli->query($query);

                        ?>

                        <table id="AcademicStaff_tutor3" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Tutorial Code</th>
                                <th>Current Tutor</th>
                                <th>Tutor</th>
                                <th>Confirm</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result_unit)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['tutor']?></td>
                                    <td>
                                        <select id="<?php echo $rows['UnitCode']?>">
                                            <?php

                                            $query="SELECT * FROM `Staff` WHERE `Code`='BUSM303_tutor'";
                                            $result_Staff=$mysqli->query($query);

                                            while ($rows_Staff = mysqli_fetch_array($result_Staff)){
                                                ?>
                                                <option value="<?php echo $rows_Staff['staffname'] ?>"><?php echo $rows_Staff['staffname'];?></option>
                                                <?php
                                            }

                                            ?>

                                        </select>

                                    </td>
                                    <td><button  class="btn btn-success Confirm">Confirm</button></td>
                                </tr>
                            <?php  }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <h4 align ="left">Change the unit details</h4>
                        <!--query for retrieving all the items from the unit table-->
                        <?php
                        $query="SELECT * FROM `unit` WHERE `coordinator`='yUC3'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tableditUC3" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['UnitCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Campuses']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <h4 align ="left">Change tutorials details</h4>
                        <!--query for retrieving all the items from the classDetail table-->
                        <?php
                        $query="SELECT * FROM `classDetail` WHERE `UnitCode`='KIT111'";
                        $result=$mysqli->query($query);
                        ?>
                        <table id="tableditUC31" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Tutorial Code</th>
                                <th>Time</th>
                                <th>Consultation</th>
                                <th>Location</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            while ($rows = mysqli_fetch_array($result)){
                                ?>
                                <!--extract the values, printing out with table-->
                                <tr>
                                    <td><?php echo $rows['tuteCode']?></td>
                                    <td><?php echo $rows['time']?></td>
                                    <td><?php echo $rows['consultation']?></td>
                                    <td><?php echo $rows['Room']?></td>
                                </tr>
                            <?php }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>




        </body>
    </html>
