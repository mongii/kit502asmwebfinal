<?php
include "../db_conn.php";
include "session.php";

$UnitCode=$_GET['col1'];
$Lecturer=$_GET['col2'];

$query ="UPDATE `unit` SET `Lecturer`='$Lecturer' WHERE `UnitCode`='$UnitCode'";
$result = $mysqli->query($query);

if($result){
    echo "The".$UnitCode."'s lecturer has successfully changed to ".$Lecturer;
}
