<?php

include('../db_conn.php');

$search= $_GET["searchContent"];

$query="SELECT * FROM `unit` 
WHERE (`UnitCode` LIKE '%".$search."%') OR (`UnitName` LIKE '%".$search."%') OR (`Lecturer` LIKE '%".$search."%')OR (`OfferingSemester` LIKE '%".$search."%')OR (`Campuses` LIKE '%".$search."%')";
$result=$mysqli->query($query);

$result_cnt = $result->num_rows;

if ($result_cnt!=0){
    echo "We found ".$result_cnt." result(s)";
    while ($rows = mysqli_fetch_array($result)){
        ?>
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Unit Code</th>
                <th>Unit Name</th>
                <th>Lecturer</th
                <th>Semester</th>
                <th>Campuses</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo $rows['UnitCode']?></td>
                <td><?php echo $rows['UnitName']?></td>
                <td><?php echo $rows['Lecturer']?></td>
                <td><?php echo $rows['OfferingSemester']?></td>
                <td><?php echo $rows['Campuses']?></td>
            </tr>
            </tbody>
        </table>
        <?php
    }
}else{
    echo 'nochange';
}
