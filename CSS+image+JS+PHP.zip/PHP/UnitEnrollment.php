
<?php
include('../db_conn.php'); //db connection
include "Login_Validation.php";
include "session.php";

if($session_access!='student'){
    echo '
        <script>
            alert("You are not allowed to access this page!");
            window.history.back();
        </script>
    ';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Unit Enrollment</title>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    
    <script src="../js/jquery.tabledit.min.js"></script>

        <script type="text/JavaScript">
            // when user clicks the check button id='check', execute the following function
            function enroll() {

                var code = $("#states:checked").val();

                $.get( "UnitEnrollment_enrol.php", {code: code} )
                    .done(function( data ) {
                        $("#output").html(data);
                       location.reload();
                    });
            }
            // when user clicks the check button id='check', execute the following function
            function unenroll() {

                var code = $("#states_unlike:checked").val();

                $.get( "UnitEnrollment_withdraw.php", {code: code} )
                    .done(function( data ) {
                        $("#output").html(data);
                        location.reload();
                    });
            }
        </script>
    </head>

    <body style="background-color: lavenderblush"
    <div class="container" id="bdiv">
    <header class="blog-header py-3">
    </div>

        <div class="row flex-nowrap justify-content-between align-items-center">
    <!--registration -->
            <!-- if user is not logged in, the registration button will be displayed  -->
            <?php
                include "session.php";
                    if ($session_user==""){
                        echo ' <div class="col-4 pt-1">
                                <a href="PHP/Registration.php" class="btn btn-success">Registration</a>
                               </div>';
                    }
                    ?>
            
            <div class="col-4 text-center">
                <h3 class="blog-header-logo text-dark" id="UDW">University of DoWell</h3>
            </div>
    <!--login & logout -->
            <!--the login button will be displayed if there is no login, and the logout button will be displayed if there is a login-->
            <div class="col-4 d-flex justify-content-end align-items-center">
                <?php
                if ($session_user==""){
                    echo'<a href="Login.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Login</a>';
                } else{
                    echo'<a href="LogOut.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center">Logout</a>';
                }
                ?>
            </div>
        </div>
    </header>

     <!-- navigation bar-->
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: black;">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <nav class="nav d-flex justify-content-between">
                <li class="navbar-brand">
                    <a class="nav-link" href="../Home.php">Home</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitDetail.php">Unit Detail</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitEnrollment.php">Unit Enrollment</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="IndividualTimetable.php">Individual Timetable</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="TutorialAllocation.php">Tutorial Allocation</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterList.php">Master List</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="MasterStaff.php">Master Staff</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="EnrolledStudentDetails.php">Enrolled Student</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UnitManagement.php">Unit Management</a>
                </li>
                <li class="navbar-brand">
                    <a class="nav-link" href="UserAccount.php">User Account</a>
                </li>
                </ul>
            </nav>
        </div>

    

        <div class="jumbotron  text-white rounded bg-dark">
            <div class="div2">
                <img src="../image/picture11.png">
            </div>
            <div>
                <h1 class="display-5 font-italic">Unit Enrollment</h1>
            </div>
        </div>
    </div>
    <!--Available Units-->
    <div class ="container">
        <div id="output"></div>
        <table class="table table-striped table-bordered" id="example1">
            <thead>
            <tr>
                <th>Unit Code</th>
                <th>Unit Name</th>
                <th>Semester</th>
                <th>Campus</th>
                <th>Type</th>
                <th>Enrol</th>
            </tr>
            </thead>
            <tbody>
            <h3>Available Unit<h3>
                    <?php
                    //query for retrieving all the items from the unit table
                    $list_query = "SELECT * FROM `unit` ";
                    $result= $mysqli->query($list_query);

                    $i=1;
                    while($row= $result->fetch_array(MYSQLI_ASSOC)){

                        //extract the values
                        $unitCode=$row['UnitCode'];
                        $unitName=$row['UnitName'];
                        $Semester=$row['OfferingSemester'];
                        $campuses=$row['Campuses'];
                        $type=$row['type'];

                        //printing out with table :)
                        if($i==1)
                        {
                            echo("<tr><td>$unitCode</td><td>$unitName</td><td>$Semester</td><td>$campuses</td><td>$type</td><td><input type='radio' id='states' name='states' value='$unitCode' checked></td></tr>");
                        }
                        else
                        {
                            echo("<tr><td>$unitCode</td><td>$unitName</td><td>$Semester</td><td>$campuses</td><td>$type</td><td><input type='radio' id='states' name='states' value='$unitCode'></td></tr>");
                        }
                        $i=$i+1;
                    }
                    ?>
            </tbody>
        </table>
        <button type='button' class='btn btn-primary' onclick='enroll()'>Enrol</button>
        <?php
        //query for retrieving all the items from the unit_enrolled table
        $list_query = "SELECT * FROM unit_enrolled WHERE username='$session_user'";

        $result= $mysqli->query($list_query);
        $result_cnt = $result->num_rows;
        if($result_cnt!=0)
        {
            echo '
				
			<table class="table table-striped table-bordered" id="example1">
				<thead>
				  <tr>
					<th>Unit Code</th>
                    <th>Unit Name</th>
                    <th>Semester</th>
                    <th>Campus</th>
                    <th>Type</th>
                    <th>Withdraw</th>
				  </tr>
				</thead>
				<tbody>
				<h3>Unit Enrolled<h3>';

            $i=1;
            while($row= $result->fetch_array(MYSQLI_ASSOC)){

                //extract the values
                $unitCode=$row['UnitCode'];
                $unitName=$row['UnitName'];
                $Semester=$row['OfferingSemester'];
                $campuses=$row['Campuses'];
                $type=$row['type'];

                //printing out with table :)
                if($i==1)
                {
                    echo("<tr><td>$unitCode</td>
                          <td>$unitName</td>
                          <td>$Semester</td>
                          <td>$campuses</td>
                          <td>$type</td><td>
                          <input type='radio' id='states_unlike' name='states_unlike' value='$unitCode' checked></td></tr>");
                }
                else
                {
                    echo("<tr><td>$unitCode</td>
                              <td>$unitName</td>
                              <td>$Semester</td>
                              <td>$campuses</td>
                              <td>$type</td><td>
                              <input type='radio' id='states_unlike' name='states_unlike' value='$unitCode'></td></tr>");
                }
                $i=$i+1;
            }
            echo "
				</tbody>
			</table>
			<button type='button' class='btn btn-primary' onclick='unenroll()'>Withdraw</button>";
        }
        ?>
    </div>
    <br>
    <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
    </body>
</html>