<?php
include('../db_conn.php'); //db connection
include "session.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <script type="text/javascript"  src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/query/3.4.1/jquery.min.js"></script>
        <link rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
              integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/login.css">

    </head>
    <body style="background-color: lavenderblush"
    <div class="container" id="bdiv">
    <header class="blog-header py-3">
    </div>
  <!-- nav bar-->
  <nav class="nav bg-light shadow-sm">
        <div>
            <a class="nav-brand" href="../Home.php">
                <img src="../image/logo.png" id="Logo">
                Back to the Main Page
            </a>
        </div>

    <!--Login form-->
    <div class="col-4 pt-1" style="text-align: center"> 
    <form class="form-signin" method="post" action="Login_process.php">
    
        <h2 class="h3 mb-3 font-weight-normal">Please sign in</h2>
        <label  class="sr-only">Name</label>
        <input type="text"  id="inputName" name="username" class="form-control" placeholder="Name"  required>
        <label  class="sr-only">Password</label>
        <input type="password"  id="inputPassword" name="password" class="form-control" placeholder="Password"  required>
        <button  class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center" type="submit">sign in</button>
        <a href="Registration.php" class="btn btn-outline-success my-2 my-sm-0" type="submit" style="text-align: center" type="submit">sign up</a>
    </form>
    </div>

    </body>
     <!-- footer -->
     <footer align="center" style="font-weight: bold; background-color: white">
            <p class="mt-5 mb-3 text-muted text-center">&copy; University of DoWell</p>
            <p>Copyright © 2020 Yen Vo. All right reserved. </p>
    </footer>
</html>